# Tic_Tac_Toe_Game
open index.html to see my game 
student:
* Marah Habashi - 211668751 
* Celine Karam - 314658428
